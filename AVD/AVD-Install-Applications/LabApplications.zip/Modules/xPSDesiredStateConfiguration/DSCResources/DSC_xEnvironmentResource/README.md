# Description

Provides a mechanism to configure and manage environment variables for a
machine or process.
