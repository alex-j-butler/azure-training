# Description

This resource downloads a remote file to the local machine.
