# Description

Provides a mechanism to manage registry keys and values on a target node.
