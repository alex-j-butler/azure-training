# Description

Provides a mechanism to configure and manage multiple xWindowsProcess resources
on a target node.
