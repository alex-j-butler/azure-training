# Description

Provides a mechanism to configure and manage multiple xWindowsFeature resources
on a target node.

## Requirements

- Target machine must be running Windows Server 2008 or later.
- Target machine must have access to the DISM PowerShell module.
- Target machine must have access to the ServerManager module.
