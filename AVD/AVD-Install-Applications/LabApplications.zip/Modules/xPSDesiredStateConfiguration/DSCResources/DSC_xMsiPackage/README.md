# Description

Provides a mechanism to install and uninstall .msi packages.
